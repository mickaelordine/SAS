package businesslogic.user;

public class Chef {
}
