package businesslogic.turn;

public interface TurnEventReceiver {

    public void updateExhaustedTurn(Turn turn);
}
