package businesslogic;

public class EventException extends Exception{
}
