package businesslogic;

public class TurnException extends Exception{
}
