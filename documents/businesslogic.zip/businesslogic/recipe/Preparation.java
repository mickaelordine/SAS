package businesslogic.recipe;

public class Preparation extends KitchenProcedure{
}
