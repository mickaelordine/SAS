package businesslogic;

public class ServiceException extends Exception{
}
